import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_core/firebase_core.dart';

import 'package:game_timer/core/services/background_service.dart';
import 'package:game_timer/core/services/firebase_service.dart';
import 'package:game_timer/core/services/notification_service.dart';
import 'package:game_timer/core/theme/app_theme.dart';
import 'package:game_timer/features/auth/presentation/screens/splash_screen.dart';
import 'package:game_timer/features/gaming_session/presentation/providers/gaming_session_provider.dart';
import 'package:game_timer/features/health/presentation/providers/health_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Firebase and other services
  await FirebaseService.initialize();
  await BackgroundService.initialize();
  final notificationService = NotificationService();
  await notificationService.initialize();

  runApp(
    ProviderScope(
      overrides: [
        notificationServiceProvider.overrideWithValue(notificationService),
      ],
      child: const GameTimerApp(),
    ),
  );
}

final notificationServiceProvider = Provider<NotificationService>((ref) {
  throw UnimplementedError();
});

class GameTimerApp extends ConsumerWidget {
  const GameTimerApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return MaterialApp(
      title: 'Game Timer',
      theme: AppTheme.darkTheme,
      home: const SplashScreen(),
      debugShowCheckedModeBanner: false,
      builder: (context, child) => MediaQuery(
        data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
        child: child!,
      ),
    );
  }
}
