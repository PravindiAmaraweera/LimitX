import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:game_timer/core/config/firebase_config.dart';

class FirebaseService {
  static Future<void> initialize() async {
    await Firebase.initializeApp(
      options: FirebaseOptions(
        apiKey: FirebaseConfig.webApiKey,
        appId: FirebaseConfig.appId,
        messagingSenderId: FirebaseConfig.messagingSenderId,
        projectId: FirebaseConfig.projectId,
        databaseURL: FirebaseConfig.databaseUrl,
        storageBucket: FirebaseConfig.storageBucket,
      ),
    );
    
    // Enable offline persistence for Realtime Database
    FirebaseDatabase.instance.setPersistenceEnabled(true);
    
    // Set database logging level
    if (const bool.fromEnvironment('dart.vm.product')) {
      FirebaseDatabase.instance.setLoggingEnabled(false);
    }
  }
  
  static Future<UserCredential> signInWithEmailAndPassword(
    String email,
    String password,
  ) async {
    try {
      return await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
    } catch (e) {
      throw _handleAuthError(e);
    }
  }
  
  static Future<UserCredential> createUserWithEmailAndPassword(
    String email,
    String password,
  ) async {
    try {
      return await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
    } catch (e) {
      throw _handleAuthError(e);
    }
  }
  
  static Future<void> resetPassword(String email) async {
    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: email);
    } catch (e) {
      throw _handleAuthError(e);
    }
  }
  
  static Future<void> signOut() async {
    await FirebaseAuth.instance.signOut();
  }
  
  static Future<void> updateUserProfile(String userId, Map<String, dynamic> data) async {
    try {
      final userRef = FirebaseDatabase.instance.ref().child('users').child(userId);
      await userRef.update(data);
    } catch (e) {
      throw Exception('Failed to update user profile: ${e.toString()}');
    }
  }
  
  static Stream<DatabaseEvent> getUserDataStream(String userId) {
    return FirebaseDatabase.instance
        .ref()
        .child('users')
        .child(userId)
        .onValue;
  }

  static User? getCurrentUser() {
    return FirebaseAuth.instance.currentUser;
  }
  
  static Exception _handleAuthError(dynamic error) {
    if (error is FirebaseAuthException) {
      switch (error.code) {
        case 'user-not-found':
          return Exception('No user found with this email.');
        case 'wrong-password':
          return Exception('Wrong password provided.');
        case 'email-already-in-use':
          return Exception('Email is already registered.');
        case 'invalid-email':
          return Exception('Invalid email address.');
        case 'weak-password':
          return Exception('Password is too weak.');
        case 'operation-not-allowed':
          return Exception('Operation not allowed.');
        case 'user-disabled':
          return Exception('User account has been disabled.');
        default:
          return Exception('Authentication failed: ${error.message}');
      }
    }
    return Exception('An unexpected error occurred: ${error.toString()}');
  }
}
