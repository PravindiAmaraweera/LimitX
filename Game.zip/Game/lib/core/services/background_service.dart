import 'dart:async';

import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:flutter_background_service_android/flutter_background_service_android.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/foundation.dart';
import 'package:game_timer/core/services/notification_service.dart';

import '../../features/gaming_session/domain/models/gaming_session.dart';

@pragma('vm:entry-point')
Future<void> onStart(ServiceInstance service) async {
  if (service is AndroidServiceInstance) {
    service.on('setAsForeground').listen((event) {
      service.setAsForegroundService();
    });

    service.on('setAsBackground').listen((event) {
      service.setAsBackgroundService();
    });
  }

  service.on('stopService').listen((event) {
    service.stopSelf();
  });

  service.on('updateGamingSession').listen((event) async {
    if (event == null) return;

    try {
      final sessionId = event['sessionId'] as String;
      final userId = event['userId'] as String;

      debugPrint('Processing session: $sessionId for user: $userId');

      final database = FirebaseDatabase.instance.ref();
      final sessionRef = database.child('gaming_sessions').child(sessionId);

      await database.child('users').child(userId).update({
        'lastActive': ServerValue.timestamp,
      });

      final snapshot = await sessionRef.get();
      if (!snapshot.exists) return;

      final data = Map<String, dynamic>.from(snapshot.value as Map);
      final startTime = DateTime.fromMillisecondsSinceEpoch(data['startTime'] as int);
      final lastUpdated = data['lastUpdated'] as int?;
      final now = DateTime.now();

      final timeSinceLastUpdate = lastUpdated != null
          ? now.difference(DateTime.fromMillisecondsSinceEpoch(lastUpdated))
          : now.difference(startTime);

      final previousDuration = data['duration'] != null
          ? Duration(seconds: data['duration'] as int)
          : Duration.zero;

      final totalDuration = previousDuration + timeSinceLastUpdate;

      await sessionRef.update({
        'duration': totalDuration.inSeconds,
        'lastUpdated': now.millisecondsSinceEpoch,
        'currentStatus': GameSessionStatus.running.toString().split('.').last,
      });

      if (totalDuration.inMinutes >= 60) {
        final notificationService = NotificationService();
        await notificationService.showBreakReminder();
      }

      debugPrint('Session updated successfully');
    } catch (e, stackTrace) {
      debugPrint('Error in background task: $e');
      debugPrint('Stack trace: $stackTrace');
    }
  });

  Timer.periodic(const Duration(seconds: 30), (timer) async {
    if (service is AndroidServiceInstance) {
      if (await service.isForegroundService()) {
        service.setForegroundNotificationInfo(
          title: "Game Timer Running",
          content: "Tracking your gaming session",
        );
      }
    }

    service.invoke(
      'update',
      {
        'current_date': DateTime.now().toIso8601String(),
      },
    );
  });
}

class BackgroundService {
  static bool _isInitialized = false;
  static final _service = FlutterBackgroundService();

  static Future<void> initialize() async {
    if (_isInitialized) return;

    try {
      final flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
      
      // Create the notification channel first
      const androidChannel = AndroidNotificationChannel(
        'game_timer_service', // same as notificationChannelId
        'Game Timer Service',
        description: 'Used for the ongoing notification when tracking gaming sessions',
        importance: Importance.low,
      );

      // Create the channel before initializing
      await flutterLocalNotificationsPlugin
          .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
          ?.createNotificationChannel(androidChannel);

      await flutterLocalNotificationsPlugin.initialize(
        const InitializationSettings(
          android: AndroidInitializationSettings('@mipmap/ic_launcher'),
          iOS: DarwinInitializationSettings(),
        ),
      );

      await _service.configure(
        androidConfiguration: AndroidConfiguration(
          onStart: onStart,
          autoStart: false,
          isForegroundMode: true,
          notificationChannelId: 'game_timer_service',
          initialNotificationTitle: 'Game Timer',
          initialNotificationContent: 'Ready to track your gaming session',
          foregroundServiceNotificationId: 888,
        ),
        iosConfiguration: IosConfiguration(
          autoStart: false,
          onForeground: onStart,
          onBackground: onIosBackground,
        ),
      );

      _isInitialized = true;
      debugPrint('Background service initialized successfully');
    } catch (e, stackTrace) {
      debugPrint('Failed to initialize background service: $e');
      debugPrint('Stack trace: $stackTrace');
      rethrow;
    }
  }

  static Future<void> startTracking(String sessionId, String userId) async {
    try {
      if (!_isInitialized) {
        throw Exception('Background service not initialized');
      }

      debugPrint('Starting background tracking for session: $sessionId');

      await _service.startService();

       _service.invoke('updateGamingSession', {
        'sessionId': sessionId,
        'userId': userId,
      });

      debugPrint('Background tracking started successfully');
    } catch (e, stackTrace) {
      debugPrint('Failed to start background tracking: $e');
      debugPrint('Stack trace: $stackTrace');
      rethrow;
    }
  }

  static Future<void> stopTracking(String sessionId) async {
    try {
      if (!_isInitialized) {
        throw Exception('Background service not initialized');
      }

      debugPrint('Stopping background tracking for session: $sessionId');
       _service.invoke('stopService');
      debugPrint('Background tracking stopped successfully');
    } catch (e, stackTrace) {
      debugPrint('Failed to stop background tracking: $e');
      debugPrint('Stack trace: $stackTrace');
      rethrow;
    }
  }
}

@pragma('vm:entry-point')
Future<bool> onIosBackground(ServiceInstance service) async {
  return true;
}
