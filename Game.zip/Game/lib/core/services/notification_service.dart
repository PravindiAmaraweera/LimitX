import 'dart:typed_data';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:game_timer/core/config/app_config.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/standalone.dart' as tz;

class NotificationService {
  final FlutterLocalNotificationsPlugin _localNotifications;
  final FirebaseMessaging _firebaseMessaging;

  static const healthNotificationIds = {
    'break': 0,
    'session': 1,
    'health_warning': 2,
    'water': 3,
    'posture': 4,
    'eye_strain': 5,
  };

  NotificationService()
      : _localNotifications = FlutterLocalNotificationsPlugin(),
        _firebaseMessaging = FirebaseMessaging.instance;

  Future<void> initialize() async {
    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    await _localNotifications.initialize(
      const InitializationSettings(
        android: androidSettings,
        iOS: iosSettings,
      ),
    );

    await _setupNotificationChannels();
    await _requestNotificationPermissions();

    FirebaseMessaging.onMessage.listen(_handleForegroundMessage);
    FirebaseMessaging.onMessageOpenedApp.listen(_handleMessageOpenedApp);
    FirebaseMessaging.onBackgroundMessage(_handleBackgroundMessage);
  }

  Future<void> _setupNotificationChannels() async {
    final channels = [
      const AndroidNotificationChannel(
        AppConfig.mainNotificationChannel,
        'Main Notifications',
        description: 'Main notification channel for Gaming Time Tracker',
        importance: Importance.high,
        enableVibration: true,
        enableLights: true,
        ledColor: Colors.green,
      ),
      const AndroidNotificationChannel(
        AppConfig.healthNotificationChannel,
        'Health Reminders',
        description: 'Health-related notifications and break reminders',
        importance: Importance.high,
        enableVibration: true,
        enableLights: true,
        ledColor: Colors.blue,
      ),
    ];

    final plugin = _localNotifications
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();

    if (plugin != null) {
      for (final channel in channels) {
        await plugin.createNotificationChannel(channel);
      }
    }
  }

  Future<void> _requestNotificationPermissions() async {
    await _firebaseMessaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );
  }

  Future<void> showBreakReminder() async {
    final androidDetails = AndroidNotificationDetails(
      AppConfig.healthNotificationChannel,
      'Health Reminders',
      channelDescription: 'Health-related notifications and break reminders',
      importance: Importance.high,
      priority: Priority.high,
      enableVibration: true,
      vibrationPattern: Int64List.fromList([0, 500, 200, 500]),
      enableLights: true,
      ledColor: Colors.blue,
      ledOnMs: 1000,
      ledOffMs: 500,
      category: AndroidNotificationCategory.reminder,
      fullScreenIntent: true,
    );

    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
      interruptionLevel: InterruptionLevel.timeSensitive,
      categoryIdentifier: 'health_reminder',
    );

    await _localNotifications.show(
      healthNotificationIds['break']!,
      '🎮 Time for a Break!',
      'You\'ve been gaming for ${AppConfig.breakInterval} minutes. Take a ${AppConfig.breakDuration} minute break to rest your eyes and stretch.',
      NotificationDetails(
        android: androidDetails,
        iOS: iosDetails,
      ),
      payload: 'break_reminder',
    );
  }

  Future<void> showSessionComplete(int duration) async {
    final androidDetails = AndroidNotificationDetails(
      AppConfig.mainNotificationChannel,
      'Main Notifications',
      channelDescription: 'Main notification channel for Gaming Time Tracker',
      importance: Importance.high,
      priority: Priority.high,
      enableVibration: true,
      vibrationPattern: Int64List.fromList([0, 300, 200, 300]),
      enableLights: true,
      ledColor: Colors.green,
      category: AndroidNotificationCategory.status,
    );

    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
      interruptionLevel: InterruptionLevel.active,
      categoryIdentifier: 'session_complete',
    );

    final hours = duration ~/ 60;
    final minutes = duration % 60;
    final timeText = hours > 0
        ? '$hours hours and $minutes minutes'
        : '$minutes minutes';

    await _localNotifications.show(
      healthNotificationIds['session']!,
      '🏆 Gaming Session Complete',
      'Great session! You played for $timeText. Remember to stretch and hydrate.',
      NotificationDetails(
        android: androidDetails,
        iOS: iosDetails,
      ),
      payload: 'session_complete',
    );
  }

  Future<void> showCustomNotification(
      String title,
      String body, {
        String? payload,
        bool isHealthRelated = true,
      }) async {
    final channel = isHealthRelated
        ? AppConfig.healthNotificationChannel
        : AppConfig.mainNotificationChannel;

    final androidDetails = AndroidNotificationDetails(
      channel,
      isHealthRelated ? 'Health Reminders' : 'Main Notifications',
      channelDescription: isHealthRelated
          ? 'Health-related notifications and break reminders'
          : 'Main notification channel for Gaming Time Tracker',
      importance: Importance.high,
      priority: Priority.high,
      enableVibration: true,
      enableLights: true,
      ledColor: isHealthRelated ? Colors.blue : Colors.green,
      category: isHealthRelated
          ? AndroidNotificationCategory.reminder
          : AndroidNotificationCategory.status,
    );

    final iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
      interruptionLevel: isHealthRelated
          ? InterruptionLevel.timeSensitive
          : InterruptionLevel.active,
      categoryIdentifier: isHealthRelated ? 'health_reminder' : 'general',
    );

    await _localNotifications.show(
      healthNotificationIds['health_warning']!,
      title,
      body,
      NotificationDetails(
        android: androidDetails,
        iOS: iosDetails,
      ),
      payload: payload,
    );
  }

  Future<void> _handleForegroundMessage(RemoteMessage message) async {
    if (message.notification != null) {
      await showCustomNotification(
        message.notification!.title ?? 'New Message',
        message.notification!.body ?? '',
        payload: message.data['type'],
        isHealthRelated: message.data['type']?.toString().contains('health') ?? false,
      );
    }
  }

  void _handleMessageOpenedApp(RemoteMessage message) {
    print('Message opened app: ${message.data}');
  }

  Future<void> scheduleBreakReminder(Duration interval) async {
    tz.initializeTimeZones();
    final location = tz.getLocation('Asia/Colombo');
    final scheduledDate = tz.TZDateTime.now(location).add(interval);

    await _localNotifications.zonedSchedule(
      healthNotificationIds['break']!,
      '🎮 Time for a Break!',
      'You\'ve been gaming for a while. Take a ${AppConfig.breakDuration} minute break to rest your eyes and stretch.',
      scheduledDate,
      NotificationDetails(
        android: AndroidNotificationDetails(
          AppConfig.healthNotificationChannel,
          'Health Reminders',
          channelDescription: 'Health-related notifications and break reminders',
          importance: Importance.high,
          priority: Priority.high,
        ),
        iOS: const DarwinNotificationDetails(
          presentAlert: true,
          presentBadge: true,
          presentSound: true,
        ),
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle, // ✅ Required now
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  Future<void> cancelBreakReminder() async {
    await _localNotifications.cancel(healthNotificationIds['break']!);
  }
}

@pragma('vm:entry-point')
Future<void> _handleBackgroundMessage(RemoteMessage message) async {
  print('Handling background message: ${message.data}');
}
