class AppConfig {
  // App settings
  static const String appName = 'Gaming Time Tracker';
  static const String appVersion = '1.0.0';
  
  // API endpoints
  static const String geminiApiEndpoint = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent';
  
  // Feature flags
  static const bool enableNotifications = true;
  static const bool enableHealthTracking = true;
  static const bool enableGeminiAI = true;
  
  // Notification channels
  static const String mainNotificationChannel = 'gaming_tracker_main';
  static const String healthNotificationChannel = 'gaming_tracker_health';


  // Session settings
  static const int minSessionDuration = 5; // minutes
  static const int maxSessionDuration = 720; // 12 hours
  
  // Health recommendations
  static const int maxDailyPlaytime = 360; // 6 hours
  static const int breakInterval = 60; // Recommend break every 60 minutes
  static const int breakDuration = 10; // 10 minutes break
}
