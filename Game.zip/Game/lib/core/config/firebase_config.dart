class FirebaseConfig {
  static const String webApiKey = 'AIzaSyB3U37W_aFwr1txCsQcqojT1JYLIGFU-7c';
  static const String androidApiKey = 'YOUR_ANDROID_API_KEY';  // Replace with your Android API key
  static const String iosApiKey = 'YOUR_IOS_API_KEY';  // Replace with your iOS API key
  static const String projectId = 'suwanena';
  static const String messagingSenderId = '385811252779';
  static const String appId = '1:385811252779:web:f9cc03a5acd5d653778c6e';
  static const String databaseUrl = 'https://suwanena-default-rtdb.firebaseio.com';
  static const String storageBucket = 'suwanena.appspot.com';
}
