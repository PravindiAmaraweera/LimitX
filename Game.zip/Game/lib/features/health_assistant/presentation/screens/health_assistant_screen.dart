import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:game_timer/features/resources/PDFLibraryScreen.dart';
import 'package:google_generative_ai/google_generative_ai.dart';

class HealthAssistantScreen extends ConsumerStatefulWidget {
  const HealthAssistantScreen({super.key});

  @override
  ConsumerState<HealthAssistantScreen> createState() => _HealthAssistantScreenState();
}

class _HealthAssistantScreenState extends ConsumerState<HealthAssistantScreen> {
  final TextEditingController _questionController = TextEditingController();
  final List<Message> _messages = [];
  bool _isLoading = false;

  final model = GenerativeModel(
    model: 'gemini-2.0-flash',
    apiKey: 'AIzaSyA-8YhEKXGhDYRep9UDg-WvrL98GPLCCZ8',
  );

  final List<String> _healthSlogans = [
    "Game Smart, Stay Healthy",
    "Balance Gaming with Life",
    "Take Breaks, Play Better",
    "Health First, Gaming Second",
    "Move More, Game Better"
  ];

  @override
  void dispose() {
    _questionController.dispose();
    super.dispose();
  }

  Future<void> _askQuestion() async {
    final question = _questionController.text.trim();
    if (question.isEmpty) return;

    setState(() {
      _isLoading = true;
      _messages.add(Message(role: 'user', text: question));
    });

    try {
      final prompt = '''
      You are a gaming health assistant. Provide concise, helpful advice about:
      - Healthy gaming habits
      - Preventing gaming-related health issues
      - Balancing gaming and physical activity
      - Mental health in gaming

      User question: $question
      ''';

      final response = await model.generateContent([Content.text(prompt)]);

      setState(() {
        _messages.add(
          Message(role: 'assistant', text: response.text ?? 'No response generated.'),
        );
        _isLoading = false;
      });

      _questionController.clear();
    } catch (e) {
      setState(() {
        _isLoading = false;
        _messages.add(
          Message(role: 'assistant', text: 'Error: Unable to get response.\n${e.toString()}'),
        );
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
       // title: const Text('Health Assistant'),
        actions: [
          // Health Tips button moved to top right corner with icon
          IconButton(
            icon: const Icon(Icons.health_and_safety),
            tooltip: 'View Health Tips',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const PDFLibraryScreen()),
              );
            },
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Slogan carousel
            Container(
              height: 100,
              margin: const EdgeInsets.symmetric(vertical: 16),
              child: PageView.builder(
                itemCount: _healthSlogans.length,
                itemBuilder: (context, index) {
                  return Container(
                    margin: const EdgeInsets.symmetric(horizontal: 8),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Theme.of(context).colorScheme.primary,
                          Theme.of(context).colorScheme.secondary,
                        ],
                      ),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Center(
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Text(
                          _healthSlogans[index],
                          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),

            // Chat messages
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: _messages.length,
                itemBuilder: (context, index) {
                  final message = _messages[index];
                  return Align(
                    alignment: message.role == 'user'
                        ? Alignment.centerRight
                        : Alignment.centerLeft,
                    child: Container(
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: message.role == 'user'
                            ? Theme.of(context).colorScheme.primary.withOpacity(0.7)
                            : Theme.of(context).colorScheme.secondaryContainer,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        message.text,
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: message.role == 'user' ? Colors.white : null,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),

            // Input area
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _questionController,
                      decoration: InputDecoration(
                        hintText: 'Ask about gaming health...',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(24),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: _isLoading ? null : _askQuestion,
                    icon: _isLoading
                        ? const SizedBox(
                      width: 24,
                      height: 24,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                        : const Icon(Icons.send),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class Message {
  final String role;
  final String text;

  Message({required this.role, required this.text});
}