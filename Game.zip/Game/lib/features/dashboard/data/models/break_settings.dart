import 'package:shared_preferences/shared_preferences.dart';

class BreakSettings {
  bool isEnabled;
  int breakInterval; // in minutes

  BreakSettings({this.isEnabled = false, this.breakInterval = 10});

  factory BreakSettings.fromJson(Map<dynamic, dynamic> json) {
    return BreakSettings(
      isEnabled: json['isEnabled'] ?? false,
      breakInterval: json['breakInterval'] ?? 10,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'isEnabled': isEnabled,
      'breakInterval': breakInterval,
    };
  }

  static Future<BreakSettings> load() async {
    final prefs = await SharedPreferences.getInstance();
    final isEnabled = prefs.getBool('breakSettings_isEnabled') ?? false;
    final breakInterval = prefs.getInt('breakSettings_breakInterval') ?? 10;

    return BreakSettings(
      isEnabled: isEnabled,
      breakInterval: breakInterval,
    );
  }

  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('breakSettings_isEnabled', isEnabled);
    await prefs.setInt('breakSettings_breakInterval', breakInterval);
  }
}
