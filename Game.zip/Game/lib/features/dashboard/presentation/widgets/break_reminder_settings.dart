// import 'package:flutter/material.dart';
// import 'package:audioplayers/audioplayers.dart';
// import '../../data/models/break_settings.dart';
// import '../../../../core/services/notification_service.dart';
//
// class BreakReminderSettings extends StatefulWidget {
//   final BreakSettings initialSettings;
//   final Function(BreakSettings) onSettingsChanged;
//
//   const BreakReminderSettings({
//     Key? key,
//     required this.initialSettings,
//     required this.onSettingsChanged,
//   }) : super(key: key);
//
//   @override
//   State<BreakReminderSettings> createState() => _BreakReminderSettingsState();
// }
//
// class _BreakReminderSettingsState extends State<BreakReminderSettings> {
//   late BreakSettings _settings;
//   final _audioPlayer = AudioPlayer();
//   final _notificationService = NotificationService();
//
//   @override
//   void initState() {
//     super.initState();
//     _settings = widget.initialSettings;
//   }
//
//   void _updateSettings(BreakSettings newSettings) {
//     setState(() {
//       _settings = newSettings;
//     });
//     widget.onSettingsChanged(newSettings);
//
//     if (newSettings.isEnabled) {
//       _notificationService.scheduleBreakReminder(
//         Duration(minutes: newSettings.reminderIntervalMinutes),
//       );
//     } else {
//       _notificationService.cancelBreakReminder();
//     }
//   }
//
//   Future<void> _playSound(String soundType) async {
//     if (!_settings.playSound) return;
//
//     String soundPath;
//     switch (soundType) {
//       case 'gentle':
//         soundPath = 'assets/sounds/sound.mp3';
//         break;
//       case 'urgent':
//         soundPath = 'assets/sounds/sound.mp3';
//         break;
//       default:
//         soundPath = 'assets/sounds/sound.mp3';
//     }
//
//     await _audioPlayer.play(AssetSource(soundPath));
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Card(
//       margin: const EdgeInsets.symmetric(vertical: 8),
//       child: Padding(
//         padding: const EdgeInsets.all(16),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               children: [
//                 Text(
//                   'Break Reminder',
//                   style: Theme.of(context).textTheme.titleMedium,
//                 ),
//                 Switch(
//                   value: _settings.isEnabled,
//                   onChanged: (value) {
//                     _updateSettings(_settings.copyWith(isEnabled: value));
//                   },
//                   activeColor: Colors.green,
//                 ),
//               ],
//             ),
//             if (_settings.isEnabled) ...[
//               const SizedBox(height: 16),
//               Text(
//                 'Reminder Interval',
//                 style: Theme.of(context).textTheme.titleSmall,
//               ),
//               Slider(
//                 value: _settings.reminderIntervalMinutes.toDouble(),
//                 min: 15,
//                 max: 120,
//                 divisions: 7,
//                 label: '${_settings.reminderIntervalMinutes} minutes',
//                 onChanged: (value) {
//                   _updateSettings(
//                     _settings.copyWith(reminderIntervalMinutes: value.round()),
//                   );
//                 },
//               ),
//               const SizedBox(height: 16),
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 children: [
//                   Text(
//                     'Play Sound',
//                     style: Theme.of(context).textTheme.titleSmall,
//                   ),
//                   Switch(
//                     value: _settings.playSound,
//                     onChanged: (value) {
//                       _updateSettings(_settings.copyWith(playSound: value));
//                     },
//                     activeColor: Colors.green,
//                   ),
//                 ],
//               ),
//               if (_settings.playSound) ...[
//                 const SizedBox(height: 16),
//                 DropdownButtonFormField<String>(
//                   value: _settings.soundType,
//                   decoration: const InputDecoration(
//                     labelText: 'Sound Type',
//                     border: OutlineInputBorder(),
//                   ),
//                   items: [
//                     DropdownMenuItem(
//                       value: 'default',
//                       child: Row(
//                         children: [
//                           const Text('Default'),
//                           IconButton(
//                             icon: const Icon(Icons.play_circle),
//                             onPressed: () => _playSound('default'),
//                           ),
//                         ],
//                       ),
//                     ),
//                     DropdownMenuItem(
//                       value: 'gentle',
//                       child: Row(
//                         children: [
//                           const Text('Gentle'),
//                           IconButton(
//                             icon: const Icon(Icons.play_circle),
//                             onPressed: () => _playSound('gentle'),
//                           ),
//                         ],
//                       ),
//                     ),
//                     DropdownMenuItem(
//                       value: 'urgent',
//                       child: Row(
//                         children: [
//                           const Text('Urgent'),
//                           IconButton(
//                             icon: const Icon(Icons.play_circle),
//                             onPressed: () => _playSound('urgent'),
//                           ),
//                         ],
//                       ),
//                     ),
//                   ],
//                   onChanged: (value) {
//                     if (value != null) {
//                       _updateSettings(_settings.copyWith(soundType: value));
//                       _playSound(value);
//                     }
//                   },
//                 ),
//               ],
//             ],
//           ],
//         ),
//       ),
//     );
//   }
//
//   @override
//   void dispose() {
//     _audioPlayer.dispose();
//     super.dispose();
//   }
// }
