import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:game_timer/features/gaming_session/domain/models/gaming_session.dart';

final dashboardProvider = StateNotifierProvider<DashboardNotifier, AsyncValue<DashboardState>>((ref) {
  return DashboardNotifier();
});

class DashboardState {
  final Map<String, dynamic> stats;
  final Map<String, int> hourlyDistribution;
  final List<GamingSession> recentSessions;

  DashboardState({
    this.stats = const {},
    this.hourlyDistribution = const {},
    this.recentSessions = const [],
  });

  DashboardState copyWith({
    Map<String, dynamic>? stats,
    Map<String, int>? hourlyDistribution,
    List<GamingSession>? recentSessions,
  }) {
    return DashboardState(
      stats: stats ?? this.stats,
      hourlyDistribution: hourlyDistribution ?? this.hourlyDistribution,
      recentSessions: recentSessions ?? this.recentSessions,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      ...stats,
      'hourlyDistribution': hourlyDistribution,
      'recentSessions': recentSessions.map((e) => e.toJson()).toList(),
    };
  }
}

class DashboardNotifier extends StateNotifier<AsyncValue<DashboardState>> {
  DashboardNotifier() : super(AsyncValue.data(DashboardState())) {
    // Initialize data
    refreshData();
  }
  final _database = FirebaseDatabase.instance.ref();
  final _auth = FirebaseAuth.instance;

  Future<void> refreshData() async {
    state = const AsyncValue.loading();
    try {
      final stats = await getGamingStats();
      final hourlyDistribution = await getHourlyDistribution();
      final recentSessions = await getCompletedSessions();
      
      state = AsyncValue.data(DashboardState(
        stats: stats,
        hourlyDistribution: hourlyDistribution,
        recentSessions: recentSessions,
      ));
    } catch (e, stack) {
      state = AsyncValue.error(e, stack);
    }
  }

  Future<List<GamingSession>> getCompletedSessions({int limit = 10}) async {
    if (_auth.currentUser == null) return [];

    try {
      final snapshot = await _database
          .child('gaming_sessions')
          .orderByChild('status')
          .equalTo('ended')
          .limitToLast(limit)
          .get();

      if (!snapshot.exists) return [];

      final sessions = (snapshot.value as Map)
          .entries
          .map((e) => GamingSession.fromJson(Map<String, dynamic>.from({
        ...e.value as Map,
        'id': e.key,
      })))
          .where((session) => session.userId == _auth.currentUser!.uid)
          .toList();

      // Sort by end time, most recent first
      sessions.sort((a, b) => b.endTime!.compareTo(a.endTime!));
      return sessions;
    } catch (e) {
      return [];
    }
  }

  Future<Map<String, dynamic>> getGamingStats() async {
    if (_auth.currentUser == null) return {};

    try {
      final sessions = await getCompletedSessions(limit: 100);
      if (sessions.isEmpty) return {};

      final now = DateTime.now();
      final thisWeek = sessions.where((s) =>
          s.endTime!.isAfter(now.subtract(const Duration(days: 7)))).toList();

      final totalHours = sessions.fold<Duration>(
          Duration.zero, (total, session) => total + (session.duration ?? Duration.zero));

      final weeklyHours = thisWeek.fold<Duration>(
          Duration.zero, (total, session) => total + (session.duration ?? Duration.zero));

      // Get most played game
      final gameMap = <String, Duration>{};
      for (final session in sessions) {
        if (session.gameName != null) {
          gameMap[session.gameName!] = (gameMap[session.gameName!] ?? Duration.zero) +
              (session.duration ?? Duration.zero);
        }
      }

      String? mostPlayedGame;
      Duration longestDuration = Duration.zero;
      gameMap.forEach((game, duration) {
        if (duration > longestDuration) {
          mostPlayedGame = game;
          longestDuration = duration;
        }
      });

      return {
        'totalSessions': sessions.length,
        'totalHours': totalHours.inHours,
        'weeklyHours': weeklyHours.inHours,
        'averageSessionLength': sessions.isEmpty ? 0 :
        totalHours.inMinutes / sessions.length,
        'mostPlayedGame': mostPlayedGame ?? 'Unknown',
        'mostPlayedGameHours': longestDuration.inHours,
        'lastPlayed': sessions.first.endTime!.toIso8601String(),
      };
    } catch (e) {
      return {};
    }
  }

  Future<Map<String, int>> getHourlyDistribution() async {
    if (_auth.currentUser == null) return {};

    try {
      final sessions = await getCompletedSessions(limit: 100);
      final hourlyStats = <String, int>{};

      // Initialize all hours
      for (var i = 0; i < 24; i++) {
        hourlyStats['$i'] = 0;
      }

      for (final session in sessions) {
        final hour = session.startTime.hour;
        hourlyStats['$hour'] = (hourlyStats['$hour'] ?? 0) + 1;
      }

      return hourlyStats;
    } catch (e) {
      return {};
    }
  }
}
