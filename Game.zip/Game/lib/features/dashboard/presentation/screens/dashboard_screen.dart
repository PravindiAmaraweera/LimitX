import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:game_timer/features/auth/presentation/screens/login_screen.dart';
import 'package:game_timer/features/gaming_session/presentation/screens/gaming_session_screen.dart';
import 'package:game_timer/features/dashboard/presentation/screens/stats_tab.dart';
import 'package:game_timer/features/dashboard/presentation/screens/profile_tab.dart';
import 'package:game_timer/features/dashboard/presentation/pages/dashboard_page.dart';
import 'package:game_timer/features/health_assistant/presentation/screens/health_assistant_screen.dart';

class DashboardScreen extends ConsumerStatefulWidget {
  const DashboardScreen({super.key});

  @override
  ConsumerState<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends ConsumerState<DashboardScreen> {
  int _selectedIndex = 0; // Default to Dashboard page

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Game Timer'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await FirebaseAuth.instance.signOut();
              if (mounted) {
                Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (context) => const LoginScreen()),
                );
              }
            },
          ),
        ],
      ),
      body: IndexedStack(
        index: _selectedIndex,
        children: [
          const DashboardPage(),
          StatsTab(),
          GamingSessionScreen(),
          const HealthAssistantScreen(),
          ProfileTab(),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.dashboard),
            label: 'Dashboard',
          ),
          NavigationDestination(
            icon: Icon(Icons.bar_chart),
            label: 'Stats',
          ),
          NavigationDestination(
            icon: Icon(Icons.timer),
            label: 'Gaming',
          ),
          NavigationDestination(
            icon: Icon(Icons.health_and_safety),
            label: 'Health',
          ),

          NavigationDestination(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}
