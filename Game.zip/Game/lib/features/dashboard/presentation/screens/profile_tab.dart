import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';
import 'package:intl/intl.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import '../../../../core/services/notifications_service.dart';
import '../widgets/break_reminder_settings.dart';
import '../../data/models/break_settings.dart';

class ProfileTab extends StatefulWidget {
  @override
  _ProfileTabState createState() => _ProfileTabState();
}

class _ProfileTabState extends State<ProfileTab> {
  final user = FirebaseAuth.instance.currentUser;
  bool isEditing = false;
  bool isLoading = false;
  TextEditingController nameController = TextEditingController();
  TextEditingController bioController = TextEditingController();
  TextEditingController favoriteGameController = TextEditingController();
  File? _newImage;
  String? bio;
  String? favoriteGame;
  int totalGamingHours = 0;
  DateTime? lastActive;
  double profileCompletion = 0;
  BreakSettings breakSettings = BreakSettings(); // default fallback
  Timer? _breakTimer;
  late NotificationSService notificationService;

  @override
  void initState() {
    super.initState();
    _loadUserData();
    _loadBreakSettings();
    notificationService = NotificationSService();
    notificationService.init();
  }

  @override
  void dispose() {
    nameController.dispose();
    bioController.dispose();
    favoriteGameController.dispose();
    _breakTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadBreakSettings() async {
    try {
      final settings = await BreakSettings.load();
      setState(() {
        breakSettings = settings;
        if (breakSettings.isEnabled) {
          _startBreakReminder();
        }
      });
    } catch (e) {
      setState(() {
        breakSettings = BreakSettings();
      });
    }
  }

  Future<void> _loadUserData() async {
    setState(() => isLoading = true);
    try {
      final dbRef = FirebaseDatabase.instance.ref('users/${user!.uid}');
      final snapshot = await dbRef.get();
      if (snapshot.exists) {
        final data = Map<String, dynamic>.from(snapshot.value as Map);
        setState(() {
          nameController.text = user?.displayName ?? '';
          bioController.text = data['bio']?.toString() ?? '';
          favoriteGameController.text = data['favoriteGame']?.toString() ?? '';
          bio = data['bio']?.toString();
          favoriteGame = data['favoriteGame']?.toString();
          totalGamingHours = (data['totalGamingHours'] as num?)?.toInt() ?? 0;
          lastActive = data['lastActive'] != null
              ? DateTime.fromMillisecondsSinceEpoch(data['lastActive'] as int)
              : null;
          _calculateProfileCompletion();
        });
      }
    } catch (e) {
      debugPrint('Error loading user data: $e');
    } finally {
      setState(() => isLoading = false);
    }
  }

  Future<void> _pickImage() async {
    final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _newImage = File(pickedFile.path);
      });
    }
  }

  Future<File> _compressImage(File file) async {
    final bytes = await file.readAsBytes();
    final image = img.decodeImage(bytes);
    if (image == null) return file;

    final compressedImage = img.copyResize(image, width: 800);
    final tempDir = await getTemporaryDirectory();
    final tempFile = File('${tempDir.path}/compressed_${DateTime.now().millisecondsSinceEpoch}.jpg');
    await tempFile.writeAsBytes(img.encodeJpg(compressedImage, quality: 85));
    return tempFile;
  }

  Future<String?> _uploadImage(File image) async {
    setState(() => isLoading = true);
    try {
      final compressedImage = await _compressImage(image);
      final ref = FirebaseStorage.instance.ref('profile_images/${user!.uid}.jpg');
      await ref.putFile(compressedImage);
      final downloadUrl = await ref.getDownloadURL();

      final dbRef = FirebaseDatabase.instance.ref('users/${user!.uid}');
      await dbRef.update({'photoUrl': downloadUrl});
      _calculateProfileCompletion();
      return downloadUrl;
    } catch (e) {
      _showErrorSnackBar('Error uploading image: ${e.toString()}');
      return null;
    } finally {
      setState(() => isLoading = false);
    }
  }

  void _calculateProfileCompletion() {
    int completedFields = 0;
    final totalFields = 5;

    if (user?.photoURL != null) completedFields++;
    if (nameController.text.isNotEmpty) completedFields++;
    if (bioController.text.isNotEmpty) completedFields++;
    if (favoriteGameController.text.isNotEmpty) completedFields++;
    if (totalGamingHours > 0) completedFields++;

    setState(() {
      profileCompletion = (completedFields / totalFields) * 100;
    });
  }

  Future<void> _saveChanges() async {
    setState(() => isLoading = true);
    try {
      String? photoUrl = user!.photoURL;

      if (_newImage != null) {
        photoUrl = await _uploadImage(_newImage!);
      }

      await user!.updateDisplayName(nameController.text);
      if (photoUrl != null) {
        await user!.updatePhotoURL(photoUrl);
      }
      await user!.reload();

      final dbRef = FirebaseDatabase.instance.ref('users/${user!.uid}');
      await dbRef.update({
        'displayName': nameController.text,
        'bio': bioController.text,
        'favoriteGame': favoriteGameController.text,
        'lastActive': DateTime.now().millisecondsSinceEpoch,
      });

      _calculateProfileCompletion();

      setState(() {
        isEditing = false;
        _newImage = null;
        bio = bioController.text;
        favoriteGame = favoriteGameController.text;
      });

      _showSuccessSnackBar('Profile updated successfully!');
    } catch (e) {
      _showErrorSnackBar('Error updating profile: ${e.toString()}');
    } finally {
      setState(() => isLoading = false);
    }
  }

  Future<void> _deleteAccount() async {
    try {
      // Get current user credentials
      final passwordController = TextEditingController();
      final result = await showDialog<Map<String, String>>(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
          backgroundColor: Colors.grey[900],
          title: const Text('Confirm Password', style: TextStyle(color: Colors.white)),
          content: TextField(
            controller: passwordController,
            obscureText: true,
            decoration: InputDecoration(
              labelText: 'Password',
              labelStyle: TextStyle(color: Colors.grey[400]),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              filled: true,
              fillColor: Colors.grey[850],
            ),
            style: const TextStyle(color: Colors.white),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop({'password': passwordController.text});
              },
              child: const Text('Confirm', style: TextStyle(color: Colors.red)),
            ),
          ],
        ),
      );

      if (result == null || result['password'] == null) return;

      // Re-authenticate user
      final credential = EmailAuthProvider.credential(
        email: user!.email!,
        password: result['password']!,
      );
      await user!.reauthenticateWithCredential(credential);

      // Delete user data from Realtime Database
      final dbRef = FirebaseDatabase.instance.ref('users/${user!.uid}');
      await dbRef.remove();

      // Delete profile image from Storage if exists
      try {
        final storageRef = FirebaseStorage.instance.ref('profile_images/${user!.uid}.jpg');
        await storageRef.delete();
      } catch (_) {}

      // Delete user account
      await user!.delete();

      if (mounted) {
        _showSuccessSnackBar('Account deleted successfully');
        Navigator.of(context).pushNamedAndRemoveUntil('/auth', (route) => false);
      }
    } catch (e) {
      if (mounted) {
        if (e is FirebaseAuthException) {
          switch (e.code) {
            case 'wrong-password':
              _showErrorSnackBar('Incorrect password');
              break;
            case 'requires-recent-login':
              _showErrorSnackBar('Please re-enter your password to delete account');
              break;
            default:
              _showErrorSnackBar('Failed to delete account: ${e.message}');
          }
        } else {
          _showErrorSnackBar('Failed to delete account: ${e.toString()}');
        }
      }
    }
  }

  void _startBreakReminder() {
    if (breakSettings.isEnabled) {
      _breakTimer?.cancel();
      _breakTimer = Timer.periodic(
        Duration(minutes: breakSettings.breakInterval),
            (timer) {
          notificationService.showNotification(
            'Break Reminder',
            'Time to take a break!',
          );
        },
      );
    }
  }

  void _stopBreakReminder() {
    _breakTimer?.cancel();
    _breakTimer = null;
  }

  void _showSuccessSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.green),
    );
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (user == null) return const Center(child: Text("User not found"));

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _buildProfileCompletionCard(),
          const SizedBox(height: 16),
          _buildProfileCard(),
        ],
      ),
    );
  }

  Widget _buildProfileCompletionCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Profile Completion',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: Colors.white),
          ),
          const SizedBox(height: 8),
          LinearProgressIndicator(
            value: profileCompletion / 100,
            backgroundColor: Colors.grey[700],
            valueColor: const AlwaysStoppedAnimation<Color>(Colors.purple),
          ),
          const SizedBox(height: 8),
          Text(
            '${profileCompletion.toStringAsFixed(0)}% Complete',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.grey[400]),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileCard() {
    return Card(
      elevation: 4,
      color: Colors.grey[900],
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildProfileHeader(),
            const SizedBox(height: 16),
            if (isEditing) ...[
              _buildEditableFields(),
            ] else ...[
              _buildReadOnlyFields(),
            ],
            const SizedBox(height: 24),

            const SizedBox(height: 24),
            if (isLoading)
              const CircularProgressIndicator()
            else
              _buildActionButtons(),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileHeader() {
    return Column(
      children: [
        Stack(
          alignment: Alignment.bottomRight,
          children: [
            CircleAvatar(
              radius: 60,
              backgroundImage: _newImage != null
                  ? FileImage(_newImage!)
                  : (user!.photoURL != null ? NetworkImage(user!.photoURL!) : null)
              as ImageProvider<Object>?,
              child: user!.photoURL == null && _newImage == null
                  ? Text(
                user!.email?.substring(0, 1).toUpperCase() ?? '?',
                style: const TextStyle(fontSize: 36, fontWeight: FontWeight.bold),
              )
                  : null,
            ),
            Positioned(
              bottom: 0,
              right: 4,
              child: GestureDetector(
                onTap: _pickImage,
                child: const CircleAvatar(
                  backgroundColor: Colors.white,
                  child: Icon(Icons.camera_alt, color: Colors.green),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        isEditing
            ? TextField(
          controller: nameController,
          decoration: InputDecoration(
            labelText: "Display Name",
            labelStyle: TextStyle(color: Colors.grey[400]),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
          ),
        )
            : Text(
          user!.displayName ?? user!.email ?? 'Gamer',
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        const SizedBox(height: 8),
        Text(
          user!.email ?? '',
          style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: Colors.grey[400]),
        ),
        if (lastActive != null) ...[
          const SizedBox(height: 16),
          Text(
            'Last Active: ${DateFormat('MMM d, y h:mm a').format(lastActive!)}',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.grey[400]),
          ),
        ],
        const SizedBox(height: 16),
        Text(
          'Total Gaming Hours: $totalGamingHours',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(color: Colors.purple[700]),
        ),
      ],
    );
  }

  Widget _buildEditableFields() {
    return Column(
      children: [
        TextField(
          controller: bioController,
          maxLines: 3,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            labelText: 'Bio',
            labelStyle: TextStyle(color: Colors.grey[400]),
            hintText: 'Tell us about yourself...',
            hintStyle: TextStyle(color: Colors.grey[600]),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.grey[700]!),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.grey[700]!),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Colors.purple),
            ),
            filled: true,
            fillColor: Colors.grey[850],
          ),
        ),
        const SizedBox(height: 16),
        TextField(
          controller: favoriteGameController,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            labelText: 'Favorite Game',
            labelStyle: TextStyle(color: Colors.grey[400]),
            hintText: 'What\'s your favorite game?',
            hintStyle: TextStyle(color: Colors.grey[600]),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.grey[700]!),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Colors.grey[700]!),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Colors.purple),
            ),
            filled: true,
            fillColor: Colors.grey[850],
          ),
        ),
      ],
    );
  }

  Widget _buildReadOnlyFields() {
    final textStyle = TextStyle(color: Colors.grey[300]);
    return Column(
      children: [
        if (bio?.isNotEmpty ?? false) ...[
          Text('Bio', style: Theme.of(context).textTheme.titleSmall?.copyWith(color: Colors.grey[400])),
          const SizedBox(height: 8),
          Text(bio!, style: textStyle),
          const SizedBox(height: 16),
        ],
        if (favoriteGame?.isNotEmpty ?? false) ...[
          Text('Favorite Game', style: Theme.of(context).textTheme.titleSmall?.copyWith(color: Colors.grey[400])),
          const SizedBox(height: 8),
          Text(favoriteGame!, style: textStyle),
        ],
      ],
    );
  }

  Widget _buildActionButtons() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton.icon(
              icon: Icon(isEditing ? Icons.save : Icons.edit),
              label: Text(isEditing ? "Save" : "Edit"),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.purple,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: () {
                if (isEditing) {
                  _saveChanges();
                } else {
                  setState(() {
                    isEditing = true;
                  });
                }
              },
            ),
            const SizedBox(width: 16),
            OutlinedButton.icon(
              icon: const Icon(Icons.logout),
              label: const Text("Logout"),
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.purple,
                side: const BorderSide(color: Colors.purple),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: () async {
                try {
                  await FirebaseAuth.instance.signOut();
                  if (mounted) {
                    Navigator.of(context).pushNamedAndRemoveUntil('/auth', (route) => false);
                  }
                } catch (e) {
                  if (mounted) {
                    _showErrorSnackBar('Failed to logout: ${e.toString()}');
                  }
                }
              },
            ),
          ],
        ),
        const SizedBox(height: 12),
        TextButton.icon(
          icon: const Icon(Icons.delete_forever, color: Colors.red),
          label: const Text(
            "Delete Account",
            style: TextStyle(color: Colors.red),
          ),
          onPressed: () {
            showDialog(
              context: context,
              builder: (_) => AlertDialog(
                title: const Text("Confirm Delete"),
                content: const Text("Are you sure you want to delete your account?"),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text("Cancel"),
                  ),
                  TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                      _deleteAccount();
                    },
                    child: const Text("Delete", style: TextStyle(color: Colors.red)),
                  ),
                ],
              ),
            );
          },
        ),
        const SizedBox(height: 12),
        SwitchListTile(
          title: const Text("Enable Break Reminder"),
          value: breakSettings.isEnabled,
          onChanged: (bool value) {
            setState(() {
              breakSettings.isEnabled = value;
              if (value) {
                _startBreakReminder();
              } else {
                _stopBreakReminder();
              }
            });
          },
        ),
        if (breakSettings.isEnabled)
          DropdownButton<int>(
            value: breakSettings.breakInterval,
            items: [10, 20, 30, 45, 60].map((int value) {
              return DropdownMenuItem<int>(
                value: value,
                child: Text('$value minutes'),
              );
            }).toList(),
            onChanged: (int? newValue) {
              setState(() {
                breakSettings.breakInterval = newValue!;
                _stopBreakReminder();
                _startBreakReminder();
              });
            },
          ),
      ],
    );
  }
}

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
  FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    const AndroidInitializationSettings initializationSettingsAndroid =
    AndroidInitializationSettings('@mipmap/ic_launcher');

    final InitializationSettings initializationSettings =
    InitializationSettings(android: initializationSettingsAndroid);

    await flutterLocalNotificationsPlugin.initialize(initializationSettings);
  }

  Future<void> showNotification(String title, String body) async {
    const AndroidNotificationDetails androidPlatformChannelSpecifics =
    AndroidNotificationDetails(
      'break_reminder_channel',
      'Break Reminder',
      importance: Importance.max,
      priority: Priority.high,
    );

    const NotificationDetails platformChannelSpecifics =
    NotificationDetails(android: androidPlatformChannelSpecifics);

    await flutterLocalNotificationsPlugin.show(
      0,
      title,
      body,
      platformChannelSpecifics,
    );
  }
}
