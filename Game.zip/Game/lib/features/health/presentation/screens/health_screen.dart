import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:game_timer/core/theme/app_theme.dart';
import 'package:game_timer/features/health/domain/models/health_stats.dart';
import 'package:game_timer/features/health/presentation/providers/health_provider.dart';
import 'package:game_timer/features/health/presentation/widgets/health_tip_card.dart';
import 'package:game_timer/features/health/presentation/widgets/stats_card.dart';

class HealthScreen extends StatefulWidget {
  const HealthScreen({super.key});

  @override
  State<HealthScreen> createState() => _HealthScreenState();
}

class _HealthScreenState extends State<HealthScreen> {
  late Future<void> _healthDataFuture;

  @override
  void initState() {
    super.initState();
    _healthDataFuture = _loadHealthData();
  }

  Future<void> _loadHealthData() async {
    final healthProvider = Provider.of<HealthProvider>(context, listen: false);
    await healthProvider.loadHealthStats();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Health Insights'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              setState(() {
                _healthDataFuture = _loadHealthData();
              });
            },
          ),
        ],
      ),
      body: FutureBuilder<void>(
        future: _healthDataFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(
              child: Text(
                'Error loading health data: ${snapshot.error}',
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: Theme.of(context).colorScheme.error,
                    ),
              ),
            );
          }

          return Consumer<HealthProvider>(
            builder: (context, healthProvider, child) {
              final stats = healthProvider.healthStats;
              
              return SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Weekly Overview',
                      style: Theme.of(context).textTheme.headlineMedium,
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      height: 200,
                      child: _buildWeeklyChart(stats),
                    ),
                    const SizedBox(height: 24),
                    Text(
                      'Today\'s Stats',
                      style: Theme.of(context).textTheme.headlineMedium,
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: StatsCard(
                            title: 'Play Time',
                            value: '${stats.todayPlaytime.inHours}h ${stats.todayPlaytime.inMinutes % 60}m',
                            icon: Icons.timer,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: StatsCard(
                            title: 'Breaks Taken',
                            value: stats.breaksTaken.toString(),
                            icon: Icons.coffee,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),
                    Text(
                      'Health Tips',
                      style: Theme.of(context).textTheme.headlineMedium,
                    ),
                    const SizedBox(height: 16),
                    HealthTipCard(
                      title: 'Take Regular Breaks',
                      description: 'Remember to take a 5-minute break every hour to prevent eye strain and maintain good posture.',
                      actionText: 'Set Reminder',
                      onAction: () {
                        healthProvider.setBreakReminder(true);
                      },
                    ),
                    const SizedBox(height: 16),
                    HealthTipCard(
                      title: 'Stay Hydrated',
                      description: 'Keep a water bottle nearby and stay hydrated during your gaming sessions.',
                      actionText: 'Track Water',
                      onAction: () {
                        // TODO: Implement water tracking
                      },
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }

  Widget _buildWeeklyChart(HealthStats stats) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.surfaceColor,
        borderRadius: BorderRadius.circular(AppTheme.borderRadius),
        border: Border.all(
          color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
        ),
      ),
      child: BarChart(
        BarChartData(
          alignment: BarChartAlignment.spaceAround,
          maxY: stats.weeklyPlaytime.reduce((a, b) => a > b ? a : b).inHours.toDouble() + 2,
          barTouchData: BarTouchData(enabled: true),
          titlesData: FlTitlesData(
            show: true,
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (value, meta) {
                  const days = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
                  return Text(
                    days[value.toInt()],
                    style: const TextStyle(color: Colors.white70),
                  );
                },
              ),
            ),
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (value, meta) {
                  return Text(
                    '${value.toInt()}h',
                    style: const TextStyle(color: Colors.white70),
                  );
                },
              ),
            ),
            rightTitles: const AxisTitles(
              sideTitles: SideTitles(showTitles: false),
            ),
            topTitles: const AxisTitles(
              sideTitles: SideTitles(showTitles: false),
            ),
          ),
          gridData: FlGridData(
            show: true,
            drawHorizontalLine: true,
            horizontalInterval: 2,
            drawVerticalLine: false,
            getDrawingHorizontalLine: (value) {
              return FlLine(
                color: Colors.white10,
                strokeWidth: 1,
              );
            },
          ),
          borderData: FlBorderData(show: false),
          barGroups: List.generate(
            7,
            (index) => BarChartGroupData(
              x: index,
              barRods: [
                BarChartRodData(
                  toY: stats.weeklyPlaytime[index].inHours.toDouble(),
                  gradient: LinearGradient(
                    colors: [
                      Theme.of(context).colorScheme.primary,
                      Theme.of(context).colorScheme.secondary,
                    ],
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                  ),
                  width: 16,
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(6),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
