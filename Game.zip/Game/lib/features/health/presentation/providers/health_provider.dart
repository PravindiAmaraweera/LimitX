import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/foundation.dart';
import 'package:game_timer/core/config/app_config.dart';
import 'package:game_timer/features/health/domain/models/health_stats.dart';
import 'package:game_timer/core/services/notification_service.dart';
import 'package:game_timer/core/services/firebase_service.dart';

class HealthProvider extends ChangeNotifier {
  final FirebaseDatabase _database = FirebaseDatabase.instance;
  final NotificationService _notificationService;

  HealthStats _healthStats = HealthStats.initial();
  bool _isBreakTime = false;
  String? _userId;

  HealthStats get healthStats => _healthStats;
  bool get isBreakTime => _isBreakTime;

  HealthProvider(this._notificationService) {
    // Auto-initialize with current user if available
    final user = FirebaseService.getCurrentUser();
    if (user != null) {
      initializeHealthTracking(user.uid);
    }
  }

  Future<void> initializeHealthTracking(String userId) async {
    _userId = userId;
    final today = DateTime.now();

    try {
      // Load today's stats
      final todayRef = _database.ref()
          .child('health_stats')
          .child(userId)
          .child(today.toString().split(' ')[0]);

      final todaySnapshot = await todayRef.get();

      // Load weekly stats
      final weeklyStats = <Duration>[];
      for (int i = 6; i >= 0; i--) {
        final date = today.subtract(Duration(days: i));
        final dayRef = _database.ref()
            .child('health_stats')
            .child(userId)
            .child(date.toString().split(' ')[0]);

        final daySnapshot = await dayRef.get();
        if (daySnapshot.exists) {
          final dayStats = HealthStats.fromJson(
              Map<String, dynamic>.from(daySnapshot.value as Map));
          weeklyStats.add(dayStats.todayPlaytime);
        } else {
          weeklyStats.add(Duration.zero);
        }
      }

      if (todaySnapshot.exists) {
        final stats = HealthStats.fromJson(
            Map<String, dynamic>.from(todaySnapshot.value as Map));
        _healthStats = stats;
      } else {
        _healthStats = HealthStats(
          todayPlaytime: Duration.zero,
          longestSession: Duration.zero,
          breaksTaken: 0,
          breaksSkipped: 0,
          weeklyPlaytime: weeklyStats,
          lastBreakTime: today,
          date: today,
        );
        await todayRef.set(_healthStats.toJson());
      }

      notifyListeners();
    } catch (e) {
      debugPrint('Error initializing health tracking: $e');
      rethrow;
    }
  }

  Future<void> updatePlaytime(Duration additionalTime) async {
    if (_userId == null) return;

    final now = DateTime.now();
    final newPlaytime = _healthStats.todayPlaytime + additionalTime;
    final newLongestSession = newPlaytime > _healthStats.longestSession
        ? newPlaytime
        : _healthStats.longestSession;

    // Update weekly stats
    final weeklyPlaytime = List<Duration>.from(_healthStats.weeklyPlaytime);
    weeklyPlaytime[6] = newPlaytime; // Today is the last day in the list

    final newStats = HealthStats(
      todayPlaytime: newPlaytime,
      longestSession: newLongestSession,
      breaksTaken: _healthStats.breaksTaken,
      breaksSkipped: _healthStats.breaksSkipped,
      weeklyPlaytime: weeklyPlaytime,
      lastBreakTime: _healthStats.lastBreakTime,
      date: _healthStats.date,
    );

    // Check if break is needed
    if (!_isBreakTime &&
        now.difference(_healthStats.lastBreakTime).inMinutes >= AppConfig.breakInterval) {
      _isBreakTime = true;
      await _notificationService.showBreakReminder();
      notifyListeners();
    }

    await _saveStats(newStats);
  }

  Future<void> takeBreak() async {
    if (_userId == null) return;

    final now = DateTime.now();
    final newStats = HealthStats(
      todayPlaytime: _healthStats.todayPlaytime,
      longestSession: _healthStats.longestSession,
      breaksTaken: _healthStats.breaksTaken + 1,
      breaksSkipped: _healthStats.breaksSkipped,
      weeklyPlaytime: _healthStats.weeklyPlaytime,
      lastBreakTime: now,
      date: _healthStats.date,
    );

    _isBreakTime = false;

    await _saveStats(newStats);

    // Schedule next break reminder
    Future.delayed(Duration(minutes: AppConfig.breakInterval), () {
      if (!_isBreakTime) {
        _isBreakTime = true;
        _notificationService.showBreakReminder();
        notifyListeners();
      }
    });
  }

  Future<void> skipBreak() async {
    if (_userId == null) return;

    final newStats = HealthStats(
      todayPlaytime: _healthStats.todayPlaytime,
      longestSession: _healthStats.longestSession,
      breaksTaken: _healthStats.breaksTaken,
      breaksSkipped: _healthStats.breaksSkipped + 1,
      weeklyPlaytime: _healthStats.weeklyPlaytime,
      lastBreakTime: _healthStats.lastBreakTime,
      date: _healthStats.date,
    );

    _isBreakTime = false;
    await _saveStats(newStats);

    // Show warning about skipping breaks
    if (newStats.breaksSkipped >= 3) {
      await _notificationService.showCustomNotification(
        'Health Warning',
        'You have skipped multiple breaks. Remember to rest your eyes and stretch!',
      );
    }
  }

  Future<void> _saveStats(HealthStats stats) async {
    if (_userId == null) return;

    try {
      final statsRef = _database.ref()
          .child('health_stats')
          .child(_userId!)
          .child(stats.date.toString().split(' ')[0]);

      await statsRef.set(stats.toJson());
      _healthStats = stats;
      notifyListeners();
    } catch (e) {
      debugPrint('Error saving health stats: $e');
      rethrow;
    }
  }

  Future<void> loadHealthStats() async {
    final user = FirebaseService.getCurrentUser();
    if (user != null) {
      await initializeHealthTracking(user.uid);
    }
  }

  Future<void> setBreakReminder(bool enabled) async {
    if (enabled) {
      await _notificationService.scheduleBreakReminder(
        Duration(minutes: AppConfig.breakInterval),
      );
    } else {
      await _notificationService.cancelBreakReminder();
    }
  }
}
