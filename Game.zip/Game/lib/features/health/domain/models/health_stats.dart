class HealthStats {
  final Duration todayPlaytime;
  final Duration longestSession;
  final int breaksTaken;
  final int breaksSkipped;
  final List<Duration> weeklyPlaytime;
  final DateTime lastBreakTime;
  final DateTime date;

  HealthStats({
    required this.todayPlaytime,
    required this.longestSession,
    required this.breaksTaken,
    required this.breaksSkipped,
    required this.weeklyPlaytime,
    required this.lastBreakTime,
    required this.date,
  }) {
    assert(weeklyPlaytime.length == 7, 'Weekly playtime must contain exactly 7 days');
  }

  Map<String, dynamic> toJson() {
    return {
      'todayPlaytime': todayPlaytime.inMinutes,
      'longestSession': longestSession.inMinutes,
      'breaksTaken': breaksTaken,
      'breaksSkipped': breaksSkipped,
      'weeklyPlaytime': weeklyPlaytime.map((d) => d.inMinutes).toList(),
      'lastBreakTime': lastBreakTime.millisecondsSinceEpoch,
      'date': date.millisecondsSinceEpoch,
    };
  }

  factory HealthStats.fromJson(Map<String, dynamic> json) {
    final weeklyPlaytimeList = (json['weeklyPlaytime'] as List<dynamic>)
        .map((minutes) => Duration(minutes: minutes as int))
        .toList();

    return HealthStats(
      todayPlaytime: Duration(minutes: json['todayPlaytime'] as int),
      longestSession: Duration(minutes: json['longestSession'] as int),
      breaksTaken: json['breaksTaken'] as int,
      breaksSkipped: json['breaksSkipped'] as int,
      weeklyPlaytime: weeklyPlaytimeList,
      lastBreakTime: DateTime.fromMillisecondsSinceEpoch(json['lastBreakTime'] as int),
      date: DateTime.fromMillisecondsSinceEpoch(json['date'] as int),
    );
  }

  factory HealthStats.initial() {
    final now = DateTime.now();
    return HealthStats(
      todayPlaytime: Duration.zero,
      longestSession: Duration.zero,
      breaksTaken: 0,
      breaksSkipped: 0,
      weeklyPlaytime: List.generate(7, (_) => Duration.zero),
      lastBreakTime: now,
      date: now,
    );
  }
  }

