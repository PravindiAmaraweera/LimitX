enum GameSessionStatus {
  starting,
  running,
  paused,
  ended
}

class GamingSession {
  final String id;
  final String userId;
  final DateTime startTime;
  final DateTime? endTime;
  final Duration? duration;
  final String? notes;
  final GameSessionStatus status;
  final String? gameName;
  final Map<String, dynamic>? gameDetails;
  final int? lastUpdated; // timestamp of last update

  GamingSession({
    required this.id,
    required this.userId,
    required this.startTime,
    this.endTime,
    this.duration,
    this.notes,
    this.status = GameSessionStatus.running,
    this.gameName,
    this.gameDetails,
    this.lastUpdated,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'userId': userId,
      'startTime': startTime.millisecondsSinceEpoch,
      'endTime': endTime?.millisecondsSinceEpoch,
      'duration': duration?.inSeconds,
      'notes': notes,
      'status': status.toString().split('.').last,
      'gameName': gameName,
      'gameDetails': gameDetails,
      'lastUpdated': lastUpdated ?? DateTime.now().millisecondsSinceEpoch,
    };
  }

  factory GamingSession.fromJson(Map<String, dynamic> json) {
    return GamingSession(
      id: json['id'] as String,
      userId: json['userId'] as String,
      startTime: DateTime.fromMillisecondsSinceEpoch(json['startTime'] as int),
      endTime: json['endTime'] != null
          ? DateTime.fromMillisecondsSinceEpoch(json['endTime'] as int)
          : null,
      duration: json['duration'] != null
          ? Duration(seconds: json['duration'] as int)
          : null,
      notes: json['notes'] as String?,
      status: json['status'] != null
          ? GameSessionStatus.values.firstWhere(
              (e) => e.toString().split('.').last == json['status'],
              orElse: () => GameSessionStatus.running)
          : GameSessionStatus.running,
      gameName: json['gameName'] as String?,
      gameDetails: json['gameDetails'] as Map<String, dynamic>?,
      lastUpdated: json['lastUpdated'] as int?,
    );
  }
}
