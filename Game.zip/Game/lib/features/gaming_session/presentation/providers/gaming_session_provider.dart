import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/foundation.dart'; // Import for debugPrint
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:game_timer/features/gaming_session/domain/models/gaming_session.dart';
import '../../../../core/services/background_service.dart';

final gamingSessionProvider =
StateNotifierProvider<GamingSessionNotifier, AsyncValue<GamingSession?>>((ref) {
  return GamingSessionNotifier();
});

class GamingSessionNotifier extends StateNotifier<AsyncValue<GamingSession?>> {
  GamingSessionNotifier() : super(const AsyncValue.data(null)) {
    // Check for active session on initialization
    _initializeActiveSession();
  }

  final _database = FirebaseDatabase.instance.ref();
  final _auth = FirebaseAuth.instance;
  StreamSubscription<DatabaseEvent>? _sessionSubscription;

  void _listenToSessionUpdates(String sessionId) {
    _sessionSubscription?.cancel();
    _sessionSubscription = _database
        .child('gaming_sessions')
        .child(sessionId)
        .onValue
        .listen((event) {
      if (event.snapshot.value != null) {
        final updatedSession = GamingSession.fromJson(
          Map<String, dynamic>.from({
            ...event.snapshot.value as Map,
            'id': event.snapshot.key,
          }),
        );
        state = AsyncValue.data(updatedSession);
      }
    });
  }

  Future<void> _initializeActiveSession() async {
    if (_auth.currentUser == null) return;

    try {
      final snapshot = await _database
          .child('gaming_sessions')
          .orderByChild('userId')
          .equalTo(_auth.currentUser!.uid)
          .get();

      if (!snapshot.exists) return;

      final sessions = (snapshot.value as Map)
          .entries
          .map((e) => GamingSession.fromJson(Map<String, dynamic>.from({
        ...e.value as Map,
        'id': e.key,
      })))
          .toList();

      // Find the most recent active session (no endTime)
      GamingSession? activeSession;
      for (final session in sessions) {
        if (session.endTime == null) {
          activeSession = session;
          break;
        }
      }

      if (activeSession != null) {
        state = AsyncValue.data(activeSession);
        await BackgroundService.startTracking(activeSession.id, activeSession.userId);
      }
    } catch (e, stack) {
      debugPrint('Error initializing active session: $e');
    }
  }

  Future<void> startSession({String? gameName, Map<String, dynamic>? gameDetails}) async {
    if (_auth.currentUser == null) return;

    // Check if there's already an active session
    if (state.value != null && state.value!.endTime == null) {
      return; // Don't start a new session if one is already active
    }

    state = const AsyncValue.loading();
    try {
      final sessionRef = _database.child('gaming_sessions').push();
      final now = DateTime.now();
      final session = GamingSession(
        id: sessionRef.key!,
        userId: _auth.currentUser!.uid,
        startTime: now,
        status: GameSessionStatus.starting,
        gameName: gameName,
        gameDetails: gameDetails,
        lastUpdated: now.millisecondsSinceEpoch,
      );

      await sessionRef.set(session.toJson());
      await BackgroundService.startTracking(session.id, session.userId);
      
      // Update status to running after background service is started
      await sessionRef.update({
        'status': GameSessionStatus.running.toString().split('.').last,
      });

      _listenToSessionUpdates(session.id);
      state = AsyncValue.data(session);
    } catch (e, stack) {
      state = AsyncValue.error(e, stack);
    }
  }

  Future<void> endSession({String? notes, String? gameName}) async {
    final currentSession = state.value;
    if (currentSession == null) return;

    try {
      final endTime = DateTime.now();
      
      final snapshot = await _database
          .child('gaming_sessions')
          .child(currentSession.id)
          .get();
      
      if (!snapshot.exists) return;
      
      final latestSession = GamingSession.fromJson(
        Map<String, dynamic>.from({
          ...snapshot.value as Map,
          'id': snapshot.key,
        }),
      );

      final duration = latestSession.duration ?? endTime.difference(latestSession.startTime);

      final updatedSession = GamingSession(
        id: currentSession.id,
        userId: currentSession.userId,
        startTime: latestSession.startTime,
        endTime: endTime,
        duration: duration,
        notes: notes,
        status: GameSessionStatus.ended,
        gameName: gameName ?? latestSession.gameName,
        gameDetails: latestSession.gameDetails,
        lastUpdated: endTime.millisecondsSinceEpoch,
      );

      await _database
          .child('gaming_sessions')
          .child(currentSession.id)
          .update(updatedSession.toJson());

      // Update user's gaming stats
      await _database.child('users').child(currentSession.userId).update({
        'totalGamingTime': ServerValue.increment(duration.inSeconds),
        'lastActive': ServerValue.timestamp,
        'totalSessions': ServerValue.increment(1),
        'lastGamePlayed': latestSession.gameName,
      });

      await BackgroundService.stopTracking(currentSession.id);
      _sessionSubscription?.cancel();
      state = AsyncValue.data(updatedSession);
    } catch (e, stack) {
      state = AsyncValue.error(e, stack);
    }
  }

  Future<List<GamingSession>> getUserSessions() async {
    if (_auth.currentUser == null) return [];

    try {
      final snapshot = await _database
          .child('gaming_sessions')
          .orderByChild('userId')
          .equalTo(_auth.currentUser!.uid)
          .get();

      if (!snapshot.exists) return [];

      return (snapshot.value as Map)
          .entries
          .map((e) => GamingSession.fromJson(Map<String, dynamic>.from({
        ...e.value as Map,
        'id': e.key,
      })))
          .toList();
    } catch (e) {
      return [];
    }
  }

  Future<Map<String, Duration>> getWeeklyStats() async {
    final sessions = await getUserSessions();
    final stats = <String, Duration>{};
    final now = DateTime.now();
    final weekStart = now.subtract(Duration(days: now.weekday - 1));

    for (var i = 0; i < 7; i++) {
      final date = weekStart.add(Duration(days: i));
      final dateStr = '${date.year}-${date.month}-${date.day}';
      final dayTotal = sessions
          .where((session) =>
      session.startTime.year == date.year &&
          session.startTime.month == date.month &&
          session.startTime.day == date.day &&
          session.duration != null)
          .fold<Duration>(
          Duration.zero, (total, session) => total + (session.duration!));
      stats[dateStr] = dayTotal;
    }

    return stats;
  }
}
