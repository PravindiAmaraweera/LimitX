import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:game_timer/features/gaming_session/presentation/providers/gaming_session_provider.dart';
import 'package:game_timer/features/dashboard/presentation/providers/dashboard_provider.dart';

class GamingSessionScreen extends ConsumerStatefulWidget {
  const GamingSessionScreen({super.key});

  @override
  ConsumerState<GamingSessionScreen> createState() => _GamingSessionScreenState();
}

class _GamingSessionScreenState extends ConsumerState<GamingSessionScreen> {
  Timer? _timer;
  Duration _elapsed = Duration.zero;
  final _notesController = TextEditingController();
  final _gameNameController = TextEditingController();
  bool _canStartSession = false;

  @override
  void initState() {
    super.initState();
    _gameNameController.addListener(_updateStartButtonState);
  }

  void _updateStartButtonState() {
    final canStart = _gameNameController.text.trim().isNotEmpty;
    if (canStart != _canStartSession) {
      setState(() {
        _canStartSession = canStart;
      });
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _notesController.dispose();
    _gameNameController.dispose();
    super.dispose();
  }

  void _startSession() {
    ref.read(gamingSessionProvider.notifier).startSession();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        _elapsed += const Duration(seconds: 1);
      });
    });
  }

  Future<void> _endSession() async {
    _timer?.cancel();
    await ref
        .read(gamingSessionProvider.notifier)
        .endSession(
          notes: _notesController.text,
          gameName: _gameNameController.text,
        );
    if (mounted) {
      setState(() {
        _elapsed = Duration.zero;
        _canStartSession = false;
      });
      _notesController.clear();
      _gameNameController.clear(); // Clear game name for new session
      
      // Refresh the providers
      ref.refresh(dashboardProvider);
      ref.refresh(gamingSessionProvider);
    }
  }

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final hours = twoDigits(duration.inHours);
    final minutes = twoDigits(duration.inMinutes.remainder(60));
    final seconds = twoDigits(duration.inSeconds.remainder(60));
    return '$hours:$minutes:$seconds';
  }

  @override
  Widget build(BuildContext context) {
    final sessionState = ref.watch(gamingSessionProvider);

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Gaming Session',
                style: Theme.of(context).textTheme.displayMedium,
              ),
              const SizedBox(height: 48),
              Container(
                padding: const EdgeInsets.all(32),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surface,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Theme.of(context)
                          .colorScheme
                          .primary
                          .withOpacity(0.2),
                      blurRadius: 20,
                      spreadRadius: 5,
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Text(
                      _formatDuration(_elapsed),
                      style: Theme.of(context).textTheme.displayLarge?.copyWith(
                            fontFamily: 'monospace',
                            color: Theme.of(context).colorScheme.primary,
                          ),
                    ),
                    const SizedBox(height: 32),
                    if (sessionState.value == null) ...[
                      Column(
                        children: [
                          TextField(
                            controller: _gameNameController,
                            decoration: InputDecoration(
                              labelText: 'Game Name',
                              hintText: 'What game are you playing?',
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                          ),
                          const SizedBox(height: 16),
                          SizedBox(
                            width: double.infinity,
                            height: 56,
                            child: ElevatedButton(
                              onPressed: _canStartSession ? _startSession : null,
                              style: ElevatedButton.styleFrom(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              child: const Text('Start Gaming Session'),
                            ),
                          ),
                        ],
                      ),
                    ] else ...[
                      TextField(
                        controller: _notesController,
                        decoration: const InputDecoration(
                          labelText: 'Session Notes (Optional)',
                          hintText: 'How was your gaming session?',
                        ),
                        maxLines: 3,
                      ),
                      const SizedBox(height: 16),
                      SizedBox(
                        width: double.infinity,
                        height: 56,
                        child: ElevatedButton(
                          onPressed: _endSession,
                          style: ElevatedButton.styleFrom(
                            backgroundColor:
                                Theme.of(context).colorScheme.error,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          child: const Text('End Session'),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              if (sessionState.isLoading)
                const Padding(
                  padding: EdgeInsets.all(16.0),
                  child: CircularProgressIndicator(),
                ),
              if (sessionState.hasError)
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Text(
                    'Error: ${sessionState.error}',
                    style: TextStyle(color: Theme.of(context).colorScheme.error),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
